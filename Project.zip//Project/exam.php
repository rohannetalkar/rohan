<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html><head>
<meta content="text/html; charset=ISO-8859-1" http-equiv="content-type"><title>online exam.html</title>
<style>
table{
	background-image:url("456.jpg");
	font-weight:bold;
}
</style>
</head><body style="background-image:url("123.jpg");">
<form action="exam_insert.php" method="POST">
<div style="text-align: center;">
<table style="text-align: left; background-color: rgb(51, 102, 255); width: 100%; height: 27px;" border="0" cellpadding="2" cellspacing="2">
<tbody>
<tr>
<td style="width: 100%;">
<h1 style="text-align: center; color: rgb(102, 102, 204); background-color: black;">ONLINE
EXAMINATION</h1>
</td>
</tr>
</tbody>
</table>
<br>
<div style="text-align: center;">
<table style="text-align: left; background-color: rgb(51, 102, 255); width: 100%; height: 27px;" border="0" cellpadding="2" cellspacing="2">
<tbody>
<tr>
<td style="width: 100%;">IDENTIFICATION DETAILS</td>
</tr>
</tbody>
</table>
<table style="width: 100%; text-align: left; margin-left: auto; margin-right: auto;" text-align="center" border="0" cellpadding="2" cellspacing="2">
<tbody>
<tr>
<td style="text-align: center;">NAME</td>
<td align="undefined" valign="undefined"><input name="NAME"></td>
</tr>
<tr>
<td style="text-align: center;" valign="undefined">DATE
OF BIRTH</td>
<td align="undefined" valign="undefined"><input maxlength="10" name="DATE">E.G.23/12/2000</td>
</tr>
<tr>
<td style="text-align: center;">GENDER</td>
<td><input name="GENDER" value="MALE" type="radio">MALE<br>
<input name="GENDER" value="FEMALE" type="radio">FEMALE</td>
</tr>
<tr>
<td style="text-align: center;" valign="undefined">CATEGORY</td>
<td align="undefined" valign="undefined">
<select name="CATEGORY"><option>NO</option><option>YES</option></select>
</td>
</tr>
<tr>
<td style="text-align: center;" valign="undefined">PERSON
WITH DISABILITY(PD)</td>
<td align="undefined" valign="undefined">
<select name="PD"><option>NO</option><option>YES</option></select>
</td>
</tr>
<tr>
<td style="text-align: center;" valign="undefined">NAME
OF PARENT<span style="color: red;">*</span></td>
<td align="undefined" valign="undefined"><input name="PARENT"></td>
</tr>
<tr>
<td style="text-align: center;" valign="undefined">NATIONALITY<span style="color: red;">*</span></td>
<td align="undefined" valign="undefined"><input name="NATIONALITY"></td>
</tr>
</tbody>
</table>
<table style="text-align: left; background-color: rgb(51, 102, 255); width: 100%; height: 27px;" border="0" cellpadding="2" cellspacing="2">
<tbody>
<tr>
<td style="width: 100%;">PERSONAL DETAILS</td>
</tr>
</tbody>
</table>
<table style="text-align: left; width: 100%;" border="0" cellpadding="2" cellspacing="2">
<tbody>
<tr>
<td style="text-align: center;" valign="undefined">ADDRESS
FOR CORRESPONDENCE</td>
<td align="undefined" valign="undefined"><span style="color: rgb(51, 102, 255);">PLEASE <span style="font-weight: bold;">SPREAD</span> YOUR ADDRESS
ACROSS THE FOUR ADDRESSS LINE</span></td>
</tr>
<tr>
<td style="text-align: center;" valign="undefined">ADDRESS
LINE 1<span style="color: red;">*</span></td>
<td><input name="ADDRESS_LINE_1"></td>
</tr>
<tr>
<td style="text-align: center;" valign="undefined">ADDRESS
LINE 2<span style="color: red;"></span></td>
<td align="undefined" valign="undefined"><input name="ADDRESS_LINE_2"></td>
</tr>
<tr>
<td style="text-align: center;" valign="undefined">ADDRESS
LINE 3<span style="color: red;"></span></td>
<td align="undefined" valign="undefined"><input name="ADDRESS_LINE_3"></td>
</tr>
<tr>
<td style="text-align: center;" valign="undefined">ADDRESS
LINE 4<span style="color: red;"></span></td>
<td align="undefined" valign="undefined"><input name="ADDRESS_LINE_4"></td>
</tr>
<tr>
<td style="text-align: center;" valign="undefined">PINCODE
FOR ADDRESS OF CORRESPONDENCE<span style="color: red;">*</span></td>
<td align="undefined" valign="undefined"><input name="PINCODE"></td>
</tr>
<tr>
<td style="text-align: center;" valign="undefined">MOBILE/LANDLINE
PHONE WITH STD CODE<span style="color: red;">*</span></td>
<td align="undefined" valign="undefined"><input name="STD_CODE" type="number"><br>
E.G. MOBILE-091XXXXXXX2/LANDLINE-04424XXX65</td>
</tr>
<tr>
<td style="text-align: center;" valign="undefined">E-MAIL
ADDRESS</td>
<td align="undefined" valign="undefined"><input name="EMAIL"></td>
</tr>
</tbody>
</table>
<table style="text-align: left; background-color: rgb(51, 102, 255); width: 100%; height: 27px;" border="0" cellpadding="2" cellspacing="2">
<tbody>
<tr>
<td style="width: 100%;">ACADEMIC DETAILS</td>
</tr>
</tbody>
</table>
<table style="text-align: left; width: 100%;" border="0" cellpadding="2" cellspacing="2">
<tbody>
<tr>
<td style="text-align: center;">BRANCH</td>
<td align="undefined" valign="undefined"><input name="BRANCH"></td>
</tr>
<tr>
<td style="text-align: center;" valign="undefined">QUALIFYING
YEAR</td>
<td align="undefined" valign="undefined">
<select name="YEAR"><option>2016</option><option>2015</option><option>2014</option><option>2013</option></select>
</td>
</tr>
</tbody>
</table>
<div style="text-align: center;"><input text-align="CENTER" name="SUBMIT" value="SUBMIT" type="submit"><br>
</div>
</div>
</div>
</form>
</body></html>