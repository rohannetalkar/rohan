<html>
<body>
<?php
//PHP CODE
echo "HELLO WORLD!!!";
echo "<h1>WORKSHOP</h1>";
?>
</body>
</html>