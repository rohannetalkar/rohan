<?php
echo "<center><h2>Enter your Resume:</h2></center>";
?>
<form action="" method="POST">
	<center><input type="file" name="file"></center><br />
	<center><input type="submit" value="SUBMIT HERE"></center>
</form>
